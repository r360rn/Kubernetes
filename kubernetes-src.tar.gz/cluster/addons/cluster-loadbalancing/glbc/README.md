# GCE Load-Balancer Controller (GLBC) Cluster Addon

This cluster addon is composed of a 404 default backend service and deployment.
On GCE, this 404 service is used in conjunction with the
[Ingress-GCE](https://github.com/kubernetes/ingress-gce) controller.

See the Ingress-GCE docs for more information.


